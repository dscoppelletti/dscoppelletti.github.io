import SwiftUI

struct UserCreateView: View {
    
    @ObservedObject private var form = UserForm()
    @State private var next = false
    @State private var openImagePicker = false
  
    init() {
        form.userName = "ds"
        form.email = "joe@gmail.com"
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading) {
                    Button(action: {
                        self.openImagePicker = true
                    }) {
                        Image(systemName: "person.circle")
                            .frame(width: 100, height: 100, alignment: .center)
                            .scaledToFill()
                            .clipped()
                    }
                    .buttonStyle(PlainButtonStyle())
                    .frame(minWidth: 0, maxWidth: .infinity,
                           minHeight: 0, maxHeight: .infinity,
                           alignment: .center)
                    TextField("User name", text: $form.userName)
                        .textContentType(UITextContentType.name)
                        .autocapitalization(.none)
//                        .withLayout(AppL10n.Label.userName,
//                                    error: $form.userNameError)
                    Text("Message")
                    Spacer()
                    NavigationLink(
                        destination: UserCreateDataView(form: form),
                        isActive: $next
                    ) {
                        EmptyView()
                    }
                }
                .padding()
//                .imagePicker(isPresented: $openImagePicker) { uiImage in
//                    self.userDelegate.setAvatar(
//                        self.form, uiImage: uiImage)
//                }
            }
            .navigationBarTitle("Profile", displayMode: .inline)
            .navigationBarBackButtonHidden(true)
            .navigationBarItems(
                leading: Button("Cancel") {
                    // NOP
                },
                trailing: Button(action: {
                    if self.form.validatePublic() {
                        self.next = true
                    }
                }) {
                    HStack {
                        Text("Personal data")
                        Image(systemName: "chevron.right")
                    }
                }
            )
        }
    }
}

struct UserCreateView_Previews: PreviewProvider {
    static var previews: some View {
        UserCreateView()
    }
}
