import SwiftUI

class UserForm: ObservableObject {
    
      var userId: String? {
           didSet {
               if userId != oldValue {
                   changed = true
               }
           }
       }
       
       var eventId: String? {
           didSet {
               if eventId != oldValue {
                   changed = true
               }
           }
       }
       
       @Published var userName = "" {
           didSet {
               if userName != oldValue {
                   changed = true
                   validateUserName()
               }
           }
       }
       
       @Published var userNameError: LocalizedStringKey?
       
       @Published var avatarId: String? = nil {
           didSet {
               if avatarId != oldValue {
                   changed = true
               }
           }
       }
       
       @Published var avatarUrl: URL? {
           didSet {
               if (avatarUrl != oldValue) {
                   changed = true
               }
           }
       }
       
       @Published var privacyEnabled = true {
           didSet {
               if privacyEnabled != oldValue {
                   changed = true
               }
           }
       }
           
       @Published var email = "" {
           didSet {
               if email != oldValue {
                   changed = true
                   validateEmail()
               }
           }
       }
       
       @Published var emailError: LocalizedStringKey?
       
       @Published var firstName = "" {
           didSet {
               if firstName != oldValue {
                   changed = true
               }
           }
       }
       
       @Published var lastName = "" {
           didSet {
               if userName != oldValue {
                   changed = true
               }
           }
       }
       
       @Published var birthDate: Date? = nil {
           didSet {
               if birthDate != oldValue {
                   changed = true
//                   birthDateEdit = DateConverter.shared.format(birthDate)
               }
           }
       }
       
       @Published var birthDateEdit: String = "" {
           didSet {
               if birthDateEdit != oldValue {
                   changed = true
                   validateBirthDate(commit: false)
               }
           }
       }
       
       @Published var birthDateError: LocalizedStringKey?
       
        var items: [String] = [ "Item 1", "Item 2", "Item 3", "Item 4", "Item 5",
           "Item 6", "Item 7", "Item 8", "Item 9", "Item 10",
           "Item 11", "Item 12", "Item 13", "Item 14", "Item 15",
           "Item 16", "Item 17", "Item 18", "Item 19", "Item 20" ]
    
       @Published var personalCode = "" {
           didSet {
               if personalCode != oldValue {
                   changed = true
               }
           }
       }
       
       @Published var followersCount = 0 {
           didSet {
               if followersCount != oldValue {
                   changed = true
                   followersText = calcFollowersText()
               }
           }
       }
       
       @Published var followerMe = false {
           didSet {
               if followerMe != oldValue {
                   changed = true
                   followersText = calcFollowersText()
               }
           }
       }
      
       @Published var followersText: LocalizedStringKey?
       
       private func calcFollowersText() -> LocalizedStringKey {
           return "Followers"
       }
    
       @Published var followingsCount = 0 {
            didSet {
                if followingsCount != oldValue {
                    changed = true
                    followingsText = calcFollowingsText()
                }
            }
        }
        
       @Published var followingMe = false {
            didSet {
                if followingMe != oldValue {
                    changed = true
                    followingsText = calcFollowingsText()
                }
            }
       }
       
       @Published var followingsText: LocalizedStringKey?
       
       private func calcFollowingsText() -> LocalizedStringKey {
            return "Followings"
       }
       
       @Published var contactsCount = 0 {
            didSet {
                if contactsCount != oldValue {
                    changed = true
                    contactsText = calcContactsText()
                }
            }
        }
        
       @Published var contactMe = false {
            didSet {
                if contactMe != oldValue {
                    changed = true
                    contactsText = calcContactsText()
                }
            }
       }
       
       @Published var contactsText: LocalizedStringKey?
       
       private func calcContactsText() -> LocalizedStringKey {
           return "Contacts"
       }
       
       @Published var changed = false
       
       @discardableResult func validateUserName() -> Bool {
           if userName.isEmpty {
               userNameError = "Error"
               return false
           }
           
           userNameError = nil
           return true
       }
       
       @discardableResult func validateEmail() -> Bool {
            if email.isEmpty {
                emailError = "Error"
                return false
            }
            
            emailError = nil
            return true
       }
       
       @discardableResult func validateBirthDate(commit: Bool) -> Bool {
//           var value: Date?
//
//           do {
//               value = try DateConverter.shared.parse(birthDateEdit)
//           } catch {
//               birthDateError = "Error"
//               return false
//           }
//
//           if commit || value == nil {
//               birthDate = value
//           }
           
           birthDateError = nil
           return true
       }
       
       func validate() -> Bool {
           var valid = true
           
           if !validatePublic() {
               valid = false
           }
           
           if !validatePrivate() {
               valid = false
           }
           
           return valid
       }
       
       func validatePublic() -> Bool {
           var valid = true
           
           if !validateUserName() {
               valid = false
           }
           
           return valid
       }
       
       func validatePrivate() -> Bool {
           var valid = true
           
           if !validateEmail() {
               valid = false
           }
           
           if !validateBirthDate(commit: true) {
               valid = false
           }
           
           return valid
       }
}
