import SwiftUI

struct UserCreateDataView: View {
    
    @ObservedObject private var form: UserForm
    @State private var birthDate = Date()
    @State private var next = false
    @State private var openBirthDatePicker = false
    
    init(form: UserForm) {
        self.form = form
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                Toggle("Private profile", isOn: $form.privacyEnabled)
                Text(form.privacyEnabled ? "Privacy enabled" :
                    "Privacy disabled")
                HStack(alignment: .lastTextBaseline) {
                    Text("Email")
                        .font(.caption)
                    Text(form.email)
                }
                .padding(.vertical)
                TextField("First name", text: $form.firstName)
                    .textContentType(UITextContentType.givenName)
                    .autocapitalization(.words)
//                    .withLayout(AppL10n.Label.firstName)
                TextField("Last name", text: $form.lastName)
                    .textContentType(UITextContentType.familyName)
                    .autocapitalization(.words)
//                    .withLayout(AppL10n.Label.lastName)
                HStack {
                    TextField("Birth date", text: $form.birthDateEdit)
                    Button(action: {
//                        self.birthDate = (try? DateConverter.shared.parse(
//                            self.form.birthDateEdit)) ?? Date()
                        self.openBirthDatePicker = true
                    }) {
                        Image(systemName: "calendar")
                    }
                }
//                .withLayout(AppL10n.Label.birthDate,
//                            error: $form.birthDateError)
                Spacer()
                NavigationLink(
                    destination: UserCreateInterestsView(form: form),
                    isActive: $next) {
                        EmptyView()
                    }
            }
            .padding()
//            .sheet(isPresented: $openBirthDatePicker) {
//                DatePickerSheet(isPresented: self.$openBirthDatePicker,
//                                title: AppL10n.Label.birthDate,
//                                selection: self.$birthDate) { date in
//                                    self.form.birthDate = date
//                }
//            }
        }
        .navigationBarTitle("Personal data", displayMode: .inline)
        .navigationBarItems(
            trailing: Button(action: {
                if self.form.validatePrivate() {
                    self.next = true
                }
            }) {
                HStack {
                    Text("Interests")
                    Image(systemName: "chevron.right")
                }
            }
        )
    }
}

struct UserCreateDataView_Previews: PreviewProvider {
    static var previews: some View {
        let form = UserForm()
        form.email = "joe@gmail.com"
        
        return NavigationView {
            NavigationLink(
                "Test",
                destination: UserCreateDataView(form: form)
            )
        }
    }
}
