import SwiftUI

struct UserCreateInterestsView: View {
    
    @ObservedObject private var form: UserForm
    @State private var selection = Set<Int>()
    
    init(form: UserForm) {
        self.form = form
    }
    
    var body: some View {
        List() {
            ForEach (form.items, id: \.self) { item in
                Text(item)
            }
        }
        .navigationBarTitle("Interests", displayMode: .inline)
    }
}

struct UserCreateInterestsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            NavigationLink(
                "Test",
                destination: UserCreateInterestsView(form: UserForm())
            )
        }
    }
}
